package com.taxi.management;

import com.taxi.management.components.Dashboard;

public class App {
    public void run() {
        Dashboard dashboard = new Dashboard();
        dashboard.show();
    }
}
