package com.taxi.management;

public class Main {
    public static void main(String[] args) {
        App app = new App();
        app.run();
    }
}
